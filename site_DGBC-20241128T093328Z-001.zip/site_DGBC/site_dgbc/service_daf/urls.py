from django.urls import path
from .views import index, index_html, etat_voiture, liste_projets_encours, liste_voiture_services

urlpatterns = [
    path('', index, name='index'),  # Chemin vers la vue index
    path('index_html/', index_html, name='index_html'),  # Chemin vers la vue index_html
    path('etat_voiture/', etat_voiture, name='etat_voiture'),
    path('projets_encours/', liste_projets_encours, name='projets_encours'),
    path('liste_voiture_services/', liste_voiture_services, name='liste_voiture_services'),
]
