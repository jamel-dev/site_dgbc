from django.db import models

class Employe(models.Model):
    nom = models.CharField(max_length=100)
    prenom = models.CharField(max_length=100)
    cin = models.CharField(max_length=10, unique=True)
    grade = models.CharField(max_length=100)
    fonction = models.CharField(max_length=100)
    poste = models.CharField(max_length=100)
    date_embauche = models.DateField()

    def __str__(self):
        return f"{self.nom} {self.prenom}"

class VoitureService(models.Model):
    nom = models.CharField(max_length=100)
    numero_serie = models.CharField(max_length=100, unique=True)
    responsable = models.CharField(max_length=100)

    def __str__(self):
        return self.nom

class EtatVoiture(models.Model):
    EN_SERVICE = 'en service'
    EN_PANNE = 'en panne'

    ETAT_CHOICES = [
        (EN_SERVICE, 'En Service'),
        (EN_PANNE, 'En Panne'),
    ]

    nom = models.CharField(max_length=100)
    numero_serie = models.CharField(max_length=100, unique=True)
    responsable = models.CharField(max_length=100)
    etat = models.CharField(
        max_length=10,
        choices=ETAT_CHOICES,
        default=EN_SERVICE,
    )

    def __str__(self):
        return self.nom

class ProjetEncour(models.Model):
    nom_projet = models.CharField(max_length=100)
    responsable = models.CharField(max_length=100)
    grade_responsable = models.CharField(max_length=100)
    date_debut = models.DateField()
    date_fin = models.DateField()

    def __str__(self):
        return self.nom_projet

class ProjetPrevu(models.Model):
    nom_projet = models.CharField(max_length=100)
    responsable = models.CharField(max_length=100)
    grade_responsable = models.CharField(max_length=100)
    date_debut = models.DateField()
    date_fin = models.DateField()

    def __str__(self):
        return self.nom_projet
