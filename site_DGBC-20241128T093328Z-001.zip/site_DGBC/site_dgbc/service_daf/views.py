from django.shortcuts import render
from .models import EtatVoiture, ProjetEncour, VoitureService

def index(request):
    # Logique de la vue index ici
    return render(request, 'service_daf/index.html')
    
def index_html(request):
    # Logique de la vue index_html ici
    return render(request, 'service_daf/index.html')



def liste_voiture_services(request):
    # Récupérer toutes les voitures de service depuis la base de données
    voitures = VoitureService.objects.all()
    # Rendre le template 'liste_voiture_services.html' en passant les voitures dans le contexte
    return render(request, 'service_daf/liste_voiture_services.html', {'voitures': voitures})

def etat_voiture(request):
    # Récupérer tous les objets EtatVoiture
    etat_voitures = EtatVoiture.objects.all()
    # Rendre le template 'etat_voiture_dgbc.html' en passant les voitures dans le contexte
    return render(request, 'service_daf/etat_voiture_dgbc.html', {'etat_voitures': etat_voitures})

def liste_projets_encours(request):
    projets = ProjetEncour.objects.all()
    return render(request, 'service_daf/projet_encour.html', {'projets': projets})
