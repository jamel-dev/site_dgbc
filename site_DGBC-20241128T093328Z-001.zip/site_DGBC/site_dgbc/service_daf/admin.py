from django.contrib import admin
from .models import Employe, VoitureService, EtatVoiture, ProjetEncour, ProjetPrevu

class EmployeAdmin(admin.ModelAdmin):
    list_display = ('nom', 'prenom', 'cin', 'grade', 'fonction', 'poste', 'date_embauche')
    search_fields = ('nom', 'cin', 'prenom', 'poste')
    list_filter = ('date_embauche',)

class VoitureServiceAdmin(admin.ModelAdmin):
    list_display = ('nom', 'numero_serie', 'responsable')
    search_fields = ('nom', 'numero_serie')
    list_filter = ('numero_serie',)
    
class EtatVoitureAdmin(admin.ModelAdmin):
    list_display = ('nom', 'numero_serie', 'responsable', 'etat')
    search_fields = ('nom', 'numero_serie')
    list_filter = ('etat',)

class ProjetEncourAdmin(admin.ModelAdmin):
    list_display = ('nom_projet', 'responsable', 'grade_responsable', 'date_debut', 'date_fin')
    search_fields = ('nom_projet', 'responsable')
    list_filter = ('date_debut', 'date_fin')

class ProjetPrevuAdmin(admin.ModelAdmin):
    list_display = ('nom_projet', 'responsable', 'grade_responsable', 'date_debut', 'date_fin')
    search_fields = ('nom_projet', 'responsable')
    list_filter = ('date_debut', 'date_fin')

admin.site.register(EtatVoiture, EtatVoitureAdmin)
admin.site.register(VoitureService, VoitureServiceAdmin)
admin.site.register(Employe, EmployeAdmin)
admin.site.register(ProjetEncour, ProjetEncourAdmin)
admin.site.register(ProjetPrevu, ProjetPrevuAdmin)
