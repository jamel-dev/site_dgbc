from django.shortcuts import render
from .models import Projetenphaseetude, Projetprevu

def index(request):
    """
    Fonction de vue pour la page d'index.
    """
    return render(request, 'service_etude/index.html')

def liste_projets_en_phase_etude(request):
    """
    Fonction de vue pour lister tous les projets finaux.
    """
    projets = Projetenphaseetude.objects.all()
    return render(request, 'service_etude/liste_projets_en_phase_etude.html', {'projets': projets})

def liste_projets_prevus(request):
    """
    Fonction de vue pour lister tous les projets prévus.
    """
    projets = Projetprevu.objects.all()
    return render(request, 'service_etude/liste_projets_prevus.html', {'projets': projets})
