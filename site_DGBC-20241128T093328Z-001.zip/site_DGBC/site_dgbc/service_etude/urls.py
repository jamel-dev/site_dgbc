from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('projets_en_phase_etude/', views.liste_projets_en_phase_etude, name='liste_projets_en_phase_etude'),
    path('projets_prevus/', views.liste_projets_prevus, name='liste_projets_prevus'),
]
