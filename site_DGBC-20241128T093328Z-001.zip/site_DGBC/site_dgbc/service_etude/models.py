from django.db import models

class Projetenphaseetude(models.Model):
    EN_COUR_APPEL_OFFRE = 'en_cour_appel_offre'
    APPEL_CANDIDATURE = 'appel_candidature'
    PHASE_EXECUTION = 'phase_execution'
    ETAT_CHOICES = [
        (EN_COUR_APPEL_OFFRE, 'En cours d\'appel d\'offres'),
        (APPEL_CANDIDATURE, 'Appel à la candidature'),
        (PHASE_EXECUTION, 'Phase d\'exécution'),
    ]

    titre = models.CharField(max_length=200)
    budget = models.DecimalField(max_digits=10, decimal_places=2)
    maitre_d_ouvre = models.CharField(max_length=200)
    responsable = models.CharField(max_length=200)
    cin_responsable = models.CharField(max_length=200)
    grade = models.CharField(max_length=200)
    etat = models.CharField(
        max_length=50,
        choices=ETAT_CHOICES,
        default=EN_COUR_APPEL_OFFRE,
    )
    date_debut = models.DateField()
    date_fin = models.DateField()

    def __str__(self):
        return self.titre

class Projetprevu(models.Model):
    titre = models.CharField(max_length=200)
    budget = models.DecimalField(max_digits=10, decimal_places=2)
    maitre_d_ouvre = models.CharField(max_length=200)
    responsable = models.CharField(max_length=200)
    cin_responsable = models.CharField(max_length=200)
    grade = models.CharField(max_length=200)
   
    date_debut = models.DateField()

    def __str__(self):
        return self.titre
