from django.contrib import admin
from .models import Projetprevu, Projetenphaseetude

class ProjetprevuAdmin(admin.ModelAdmin):
    list_display = ('titre', 'budget', 'maitre_d_ouvre', 'responsable', 'cin_responsable', 'grade', 'date_debut')
    search_fields = ('titre', 'responsable')
    list_filter = ('date_debut',)

class ProjetenphaseetudeAdmin(admin.ModelAdmin):
    list_display = ('titre', 'budget', 'maitre_d_ouvre', 'responsable', 'cin_responsable', 'grade', 'date_debut', 'date_fin', 'etat')
    search_fields = ('titre', 'responsable', 'etat')
    list_filter = ('date_debut', 'date_fin', 'etat')

admin.site.register(Projetprevu, ProjetprevuAdmin)
admin.site.register(Projetenphaseetude, ProjetenphaseetudeAdmin)
