from django.urls import path
from .views import (
    index, index_html, BureauDEtudeListView, EntrepriseCathegorie3EtPlusListView, 
    EntrepriseCathegorie1Et2ListView, BureauDeControleListView, IngenieurConseilListView, 
    BureauGeometreExpertListView, submit_ingenieur_conseil, submit_bureau_etude,
    submit_bureau_control, submit_geometre_expert, submit_entreprise_cathegorie_1_et_2,
    submit_entreprise_cathegorie_3_et_plus
)

urlpatterns = [
    path('', index, name='index'),  # URL pour la page d'accueil
    path('index.html', index_html, name='index_html'),  # URL pour index.html
    path('bureau_etudes/', BureauDEtudeListView.as_view(), name='bureau_etude_list'),
    path('bureau_controles/', BureauDeControleListView.as_view(), name='bureau_controle_list'),
    path('ingenieurs_conseil/', IngenieurConseilListView.as_view(), name='ingenieur_conseil_list'),
    path('bureaux_geometre_expert/', BureauGeometreExpertListView.as_view(), name='bureau_geometre_expert_list'),
    path('entreprise_cathegorie_1_et_2/', EntrepriseCathegorie1Et2ListView.as_view(), name='entreprise_cathegorie_1_et_2_list'),
    path('entreprise_cathegorie3_et_plus/', EntrepriseCathegorie3EtPlusListView.as_view(), name='entreprise_cathegorie3_et_plus_list'),
    path('submit_ingenieur_conseil/', submit_ingenieur_conseil, name='submit_ingenieur_conseil'),
    path('submit-bureau-etude/', submit_bureau_etude, name='submit_bureau_etude'),
    path('submit-bureau-control/', submit_bureau_control, name='submit_bureau_control'),
    path('submit-geometre-expert/', submit_geometre_expert, name='submit_geometre_expert'),
    path('submit-entreprise-cathegorie-1-et-2/', submit_entreprise_cathegorie_1_et_2, name='submit_entreprise_cathegorie_1_et_2'),
    path('submit-entreprise-cathegorie-3-et-plus/', submit_entreprise_cathegorie_3_et_plus, name='submit_entreprise_cathegorie_3_et_plus'),
]

