from django.shortcuts import render, redirect
from django.views.generic import ListView
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.db import IntegrityError
from .models import (
    BureauDEtude, BureauDeControle, IngenieurConseil, 
    BureauGeometreExpert, EntrepriseCathegorie1Et2, EntrepriseCathegorie3EtPlus
)





def index(request):
    # Logique de la vue index ici
    return render(request, 'service_agrement/index.html')
    
def index_html(request):
    # Logique de la vue index_html ici
    return render(request, 'service_agrement/index.html')

@method_decorator(login_required, name='dispatch')
class BureauDEtudeListView(ListView):
    model = BureauDEtude
    template_name = 'service_agrement/bureau_etude_list.html'
    context_object_name = 'bureaux'

@method_decorator(login_required, name='dispatch')
class BureauDeControleListView(ListView):
    model = BureauDeControle
    template_name = 'service_agrement/bureau_controle_list.html'
    context_object_name = 'bureaux_controle'

@method_decorator(login_required, name='dispatch')
class IngenieurConseilListView(ListView):
    model = IngenieurConseil
    template_name = 'service_agrement/ingenieur_conseil_list.html'
    context_object_name = 'ingenieurs_conseil'

@method_decorator(login_required, name='dispatch')
class BureauGeometreExpertListView(ListView):
    model = BureauGeometreExpert
    template_name = 'service_agrement/bureau_geometre_expert_list.html'
    context_object_name = 'bureaux_geometre_expert'

@method_decorator(login_required, name='dispatch')
class EntrepriseCathegorie1Et2ListView(ListView):
    model = EntrepriseCathegorie1Et2
    template_name = 'service_agrement/entreprise_cathegorie_1_et_2_list.html'
    context_object_name = 'entreprises_cathegorie'

@method_decorator(login_required, name='dispatch')
class EntrepriseCathegorie3EtPlusListView(ListView):
    model = EntrepriseCathegorie3EtPlus
    template_name = 'service_agrement/entreprise_cathegorie3_et_plus_list.html'
    context_object_name = 'entreprises_cathegorie3_et_plus'
from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import BureauDEtude

def submit_bureau_etude(request):
    if request.method == 'POST':
        nom_bureau = request.POST.get('nom_bureau')
        code_tva = request.POST.get('code_tva')
        nom_et_prenom_gerant = request.POST.get('nom_et_prenom_gerant')
        diplome_gerant = request.POST.get('diplome_gerant')
        date_de_diplome_gerant = request.POST.get('date_de_diplome_gerant')
        cin_gerant = request.POST.get('cin_gerant')
        categorie_bureau = request.POST.get('categorie_bureau')
        specialite_bureau = request.POST.get('specialite_bureau')
        date_depot_dossier = request.POST.get('date_depot_dossier')

        try:
            bureau_etude = BureauDEtude(
                nom_bureau=nom_bureau,
                code_tva=code_tva,
                nom_et_prenom_gerant=nom_et_prenom_gerant,
                diplome_gerant=diplome_gerant,
                date_de_diplome_gerant=date_de_diplome_gerant,
                cin_gerant=cin_gerant,
                categorie_bureau=categorie_bureau,
                specialite_bureau=specialite_bureau,
                date_depot_dossier=date_depot_dossier
            )
            bureau_etude.save()
            # Redirige vers l'index avec un message de succès
            return redirect('index')
        except IntegrityError:
            context = {
                'error_message': 'Une erreur est survenue lors de la soumission du formulaire.'
            }
            return render(request, 'service_agrement/index.html', context)
    else:
        return HttpResponse("Cette vue accepte uniquement les requêtes POST.")


def submit_ingenieur_conseil(request):
    if request.method == 'POST':
        nom_et_prenom = request.POST.get('nom_et_prenom_ingenieur_conseil')
        cin = request.POST.get('cin_ingenieur_conseil')
        code_tva = request.POST.get('code_tva_ingenieur_conseil')
        diplome = request.POST.get('diplome_ingenieur_conseil')
        specialite = request.POST.get('specialite_bureau_ingenieur_conseil')
        date_de_diplome = request.POST.get('date_de_deplome_ingenieur_conseil')
        date_depot_dossier = request.POST.get('date_depot_dossier_ingenieur_conseil')

        ingenieur_conseil = IngenieurConseil(
            nom_et_prenom=nom_et_prenom,
            cin=cin,
            code_tva=code_tva,
            diplome=diplome,
            specialite=specialite,
            date_de_diplome=date_de_diplome,
            date_depot_dossier=date_depot_dossier
        )
        ingenieur_conseil.save()

        # Ajouter le message de succès dans le contexte de rendu de la vue index
        context = {
            'success_message': 'Votre formulaire a été soumis avec succès!'
        }
        return render(request, 'service_agrement/index.html', context)
    else:
        return HttpResponse("Cette vue accepte uniquement les requêtes POST.")
        
def submit_geometre_expert(request):
    if request.method == 'POST':
        nom_bureau = request.POST.get('nom_bureau')
        code_tva = request.POST.get('code_tva')
        nom_et_prenom_gerant = request.POST.get('nom_et_prenom_gerant')
        diplome_gerant = request.POST.get('diplome_gerant')
        date_de_diplome_gerant = request.POST.get('date_de_diplome_gerant')
        cin_gerant = request.POST.get('cin_gerant')
        categorie_bureau = request.POST.get('categorie_bureau')
        date_depot_dossier = request.POST.get('date_depot_dossier')

        try:
            bureau_geometre_expert = BureauGeometreExpert(
                nom_bureau=nom_bureau,
                code_tva=code_tva,
                nom_et_prenom_gerant=nom_et_prenom_gerant,
                diplome_gerant=diplome_gerant,
                date_de_diplome_gerant=date_de_diplome_gerant,
                cin_gerant=cin_gerant,
                categorie_bureau=categorie_bureau,
                date_depot_dossier=date_depot_dossier
            )
            bureau_geometre_expert.save()

            # Ajouter le message de succès dans le contexte de rendu de la vue index
            context = {
                'success_message': 'Votre formulaire a été soumis avec succès!'
            }
            return render(request, 'service_agrement/index.html', context)
        except Exception as e:
            # En cas d'erreur lors de l'enregistrement, renvoyer une réponse d'erreur
            return HttpResponse("Une erreur s'est produite lors de la soumission du formulaire: " + str(e))
    else:
        return HttpResponse("Cette vue accepte uniquement les requêtes POST.")

def submit_bureau_control(request):
    if request.method == 'POST':
        nom_bureau = request.POST.get('nom_bureau')
        code_tva = request.POST.get('code_tva')
        nom_et_prenom_gerant = request.POST.get('nom_et_prenom_gerant')
        diplome_gerant = request.POST.get('diplome_gerant')
        date_de_diplome_gerant = request.POST.get('date_de_diplome_gerant')
        cin_gerant = request.POST.get('cin_gerant')
        categorie_bureau = request.POST.get('categorie_bureau')
        specialite_bureau = request.POST.get('specialite_bureau')
        date_depot_dossier = request.POST.get('date_depot_dossier')

        try:
            bureau_control = BureauDeControl(
                nom_bureau=nom_bureau,
                code_tva=code_tva,
                nom_et_prenom_gerant=nom_et_prenom_gerant,
                diplome_gerant=diplome_gerant,
                date_de_diplome_gerant=date_de_diplome_gerant,
                cin_gerant=cin_gerant,
                categorie_bureau=categorie_bureau,
                specialite_bureau=specialite_bureau,
                date_depot_dossier=date_depot_dossier
            )
            bureau_control.save()

            # Ajouter le message de succès dans le contexte de rendu de la vue index
            context = {
                'success_message': 'Votre formulaire a été soumis avec succès!'
            }
            return render(request, 'service_agrement/index.html', context)
        except Exception as e:
            # En cas d'erreur lors de l'enregistrement, renvoyer une réponse d'erreur
            return HttpResponse("Une erreur s'est produite lors de la soumission du formulaire: " + str(e))
    else:
        return HttpResponse("Cette vue accepte uniquement les requêtes POST.")

def submit_entreprise_cathegorie_1_et_2(request):
    if request.method == 'POST':
        nom_entreprise = request.POST.get('nom_entreprise')
        code_tva = request.POST.get('code_tva')
        nom_et_prenom_gerant = request.POST.get('nom_et_prenom_gerant')
        diplome_gerant = request.POST.get('diplome_gerant')
        date_de_diplome_gerant = request.POST.get('date_de_diplome_gerant')
        cin_gerant = request.POST.get('cin_gerant')
        categorie_entreprise = request.POST.get('categorie_entreprise')
        specialite_entreprise = request.POST.get('specialite_entreprise')
        date_depot_dossier = request.POST.get('date_depot_dossier')

        try:
            entreprise_cathegorie_1_et_2 = EntrepriseCathegorie1Et2(
                nom_entreprise=nom_entreprise,
                code_tva=code_tva,
                nom_et_prenom_gerant=nom_et_prenom_gerant,
                diplome_gerant=diplome_gerant,
                date_de_diplome_gerant=date_de_diplome_gerant,
                cin_gerant=cin_gerant,
                categorie_entreprise=categorie_entreprise,
                specialite_entreprise=specialite_entreprise,
                date_depot_dossier=date_depot_dossier
            )
            entreprise_cathegorie_1_et_2.save()

            # Ajouter le message de succès dans le contexte de rendu de la vue index
            context = {
                'success_message': 'Votre formulaire a été soumis avec succès!'
            }
            return render(request, 'service_agrement/index.html', context)
        except Exception as e:
            # En cas d'erreur lors de l'enregistrement, renvoyer une réponse d'erreur
            return HttpResponse("Une erreur s'est produite lors de la soumission du formulaire: " + str(e))
    else:
        return HttpResponse("Cette vue accepte uniquement les requêtes POST.")

def submit_entreprise_cathegorie_3_et_plus(request):
    if request.method == 'POST':
        nom_entreprise = request.POST.get('nom_entreprise')
        code_tva = request.POST.get('code_tva')
        nom_et_prenom_gerant = request.POST.get('nom_et_prenom_gerant')
        date_de_diplome_gerant = request.POST.get('date_de_diplome_gerant')
        cin_gerant = request.POST.get('cin_gerant')
        categorie_entreprise = request.POST.get('categorie_entreprise')
        specialite_entreprise = request.POST.get('specialite_entreprise')
        date_depot_dossier = request.POST.get('date_depot_dossier')

        try:
            entreprise = EntrepriseCathegorie3EtPlus(
                nom_entreprise=nom_entreprise,
                code_tva=code_tva,
                nom_et_prenom_gerant=nom_et_prenom_gerant,
                date_de_diplome_gerant=date_de_diplome_gerant,
                cin_gerant=cin_gerant,
                categorie_entreprise=categorie_entreprise,
                specialite_entreprise=specialite_entreprise,
                date_depot_dossier=date_depot_dossier
            )
            entreprise.save()

            context = {
                'success_message': 'Votre formulaire a été soumis avec succès!'
            }
            return render(request, 'service_agrement/index.html', context)
        except Exception as e:
            return HttpResponse("Une erreur s'est produite lors de la soumission du formulaire.")
    else:
        return HttpResponse("Cette vue accepte uniquement les requêtes POST.")
