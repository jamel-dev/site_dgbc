from django.db import models
from django.core.exceptions import ValidationError
from django.utils import timezone
import re
from django.core.validators import RegexValidator


class TVACode(models.Model):
    CATEGORY_CHOICES = [
        ('IngenieurConseil', 'Ingénieur Conseil'),
        ('BureauDEtude', 'Bureau d\'Étude'),
        ('BureauDeControle', 'Bureau de Contrôle'),
        ('Entreprise', 'Entreprise'),
        ('BureauGeometreExpert', 'Geometre Expert'),     
    ]

    # Regex pour valider le format (7 chiffres suivis d'une lettre majuscule)
    code_validator = RegexValidator(
        regex=r'^\d{7}[A-Z]$',
        message='Le code TVA doit comporter 7 chiffres suivis d\'une lettre majuscule.'
    )

    code = models.CharField(
        max_length=8,  # 7 chiffres + 1 lettre
        unique=True,
        verbose_name="Code TVA",
        validators=[code_validator],  # Utiliser le validateur Regex
        help_text='Format requis: 7 chiffres suivis d\'une lettre majuscule.'
    )
    nom_entreprise_ou_bureau = models.CharField(max_length=200)
    date_patente = models.DateField(default=timezone.now)
    category = models.CharField(
        max_length=20,
        choices=CATEGORY_CHOICES,
        verbose_name="Catégorie",
    )

    def __str__(self):
        return f"{self.code} - {self.get_category_display()}"

    class Meta:
        verbose_name = "Code TVA"
        verbose_name_plural = "Codes TVA"

class IngenieurConseil(models.Model):
    ETUDE = 'en cours d\'étude'
    REFUSE = 'Refusé'
    ACCEPTE = 'Accepté'
    ETAT_CHOICES = [
        (ETUDE, 'en cours d\'étude'),
        (REFUSE, 'Refusé'),
        (ACCEPTE, 'Accepté'),
    ]

    nom_et_prenom = models.CharField(max_length=200)

    # Définir un validateur personnalisé pour le champ "cin"
    validate_cin = RegexValidator(
        regex=r'^\d{8}$',
        message="Le CIN doit contenir exactement 8 chiffres.",
    )
    cin = models.CharField(max_length=20, validators=[validate_cin], unique=True)

    # Définir un validateur personnalisé pour le champ "code_tva"
    validate_code_tva = RegexValidator(
        regex=r'^\d{7}[A-Z]$',
        message="Le code TVA doit comporter 7 chiffres suivis d'une lettre majuscule.",
    )
    code_tva = models.CharField(max_length=20, validators=[validate_code_tva], unique=True)

    diplome = models.CharField(max_length=200)
    date_de_diplome = models.DateField(default=timezone.now)
    
    SPECIALITE_CHOICES = [
        ('GCIVIL', 'génie civil'),
        ('GELEC', 'génie électrique'),
        ('GINDUS', 'génie industriel'),
        ('GEMECANIQUE', 'génie mécanique'),
        ('GENENERGETIQUE', 'génie énergétique'),
    ]
    specialite = models.CharField(max_length=200, choices=SPECIALITE_CHOICES)
    
    date_depot_dossier = models.DateField(default=timezone.now)
    numero_agrement = models.CharField(max_length=200, blank=True)
    date_agrement = models.DateField(default=None, blank=True, null=True)
    remarque = models.TextField(null=True, blank=True)

    etat = models.CharField(
        max_length=20,
        choices=ETAT_CHOICES,
        default=ETUDE,
    )

    def clean(self):
        if self.etat == 'Accepté':
            if not self.numero_agrement:
                raise ValidationError({'numero_agrement': 'Le numéro d\'agrément est obligatoire lorsque l\'état est "Accepté".'})
            if not self.date_agrement:
                raise ValidationError({'date_agrement': 'La date d\'agrément est obligatoire lorsque l\'état est "Accepté".'})
            if not re.match(r'^\d{7}[A-Z]$', self.code_tva):
                raise ValidationError({'code_tva': 'Le code TVA doit comporter 7 chiffres suivis d\'une lettre majuscule.'})
        else:
            self.numero_agrement = ''
            self.date_agrement = None

    def save(self, *args, **kwargs):
        self.clean()
        super().save(*args, **kwargs)


class BureauDEtude(models.Model):
    
    ETUDE = 'en cours d\'étude'
    REFUSE = 'Refusé'
    ACCEPTE = 'Accepté'
    ETAT_CHOICES = [
        (ETUDE, 'en cours d\'étude'),
        (REFUSE, 'Refusé'),
        (ACCEPTE, 'Accepté'),
    ]

    nom_bureau = models.CharField(max_length=200, null=True)
    code_tva = models.CharField(max_length=20)
    nom_et_prenom_gerant = models.CharField(max_length=200)
    diplome_gerant = models.CharField(max_length=200)
    date_de_diplome_gerant = models.DateField(default=timezone.now)
    cin_gerant = models.CharField(max_length=20)
    categorie_bureau = models.CharField(max_length=10, choices=[
        ('A1', 'A1'), ('A2', 'A2'), ('A3', 'A3'),
        ('B1', 'B1'), ('B2', 'B2'), ('B3', 'B3'), 
        ('B4', 'B4'), ('B5', 'B5'), ('B6', 'B6')
    ])
    
    SPECIALITE_CHOICES = [
        ('GCIVIL', 'génie civil'),
        ('GELEC', 'génie électrique'),
        ('GINDUS', 'génie industriel'),
        ('GEMECANIQUE', 'génie mécanique'),
        ('GENENERGETIQUE', 'génie énergétique'),
    ]
    specialite_bureau = models.CharField(max_length=200, choices=SPECIALITE_CHOICES)
    
    date_depot_dossier = models.DateField(default=timezone.now)
    numero_agrement = models.CharField(max_length=200, blank=True)
    date_agrement = models.DateField(default=None, blank=True, null=True)
    remarque = models.TextField(null=True, blank=True)

    etat = models.CharField(
        max_length=20,
        choices=ETAT_CHOICES,
        default=ETUDE,
    )

    def clean(self):
        if self.etat == 'Accepté':
            if not self.numero_agrement:
                raise ValidationError({'numero_agrement': 'Le numéro d\'agrément est obligatoire lorsque l\'état est "Accepté".'})
            if not self.date_agrement:
                raise ValidationError({'date_agrement': 'La date d\'agrément est obligatoire lorsque l\'état est "Accepté".'})
        else:
            self.numero_agrement = ''
            self.date_agrement = None

    def save(self, *args, **kwargs):
        self.clean()
        super().save(*args, **kwargs)

    def __str__(self):
        return ""

class BureauDeControle(models.Model):
    
    ETUDE = 'en cours d\'étude'
    REFUSE = 'Refusé'
    ACCEPTE = 'Accepté'
    ETAT_CHOICES = [
        (ETUDE, 'en cours d\'étude'),
        (REFUSE, 'Refusé'),
        (ACCEPTE, 'Accepté'),
    ]

    nom_bureau = models.CharField(max_length=200, null=True)
    code_tva = models.CharField(max_length=20)
    nom_et_prenom_gerant = models.CharField(max_length=200)
    diplome_gerant = models.CharField(max_length=200)
    date_de_diplome_gerant = models.DateField(default=timezone.now)
    cin_gerant = models.CharField(max_length=20)
    categorie_bureau = models.CharField(max_length=10, choices=[
        ('C1', 'C1'), ('C2', 'C2'), ('C3', 'C3'),
        ('D1', 'D1'), ('D2', 'D2'), ('D3', 'D3'),
    ])
    
    SPECIALITE_CHOICES = [
        ('GCIVIL', 'génie civil'),
        ('GELEC', 'génie électrique'),
        ('GINDUS', 'génie industriel'),
        ('GEMECANIQUE', 'génie mécanique'),
        ('GENENERGETIQUE', 'génie énergétique'),
    ]
    specialite_bureau = models.CharField(max_length=200, choices=SPECIALITE_CHOICES)
    
    date_depot_dossier = models.DateField(default=timezone.now)
    numero_agrement = models.CharField(max_length=200, blank=True)
    date_agrement = models.DateField(default=None, blank=True, null=True)
    remarque = models.TextField(null=True, blank=True)

    etat = models.CharField(
        max_length=20,
        choices=ETAT_CHOICES,
        default=ETUDE,
    )

    def clean(self):
        if self.etat == 'Accepté':
            if not self.numero_agrement:
                raise ValidationError({'numero_agrement': 'Le numéro d\'agrément est obligatoire lorsque l\'état est "Accepté".'})
            if not self.date_agrement:
                raise ValidationError({'date_agrement': 'La date d\'agrément est obligatoire lorsque l\'état est "Accepté".'})
        else:
            self.numero_agrement = ''
            self.date_agrement = None

    def save(self, *args, **kwargs):
        self.clean()
        super().save(*args, **kwargs)

    def __str__(self):
        return self.nom_bureau

class BureauGeometreExpert(models.Model):
    
    ETUDE = 'en cours d\'étude'
    REFUSE = 'Refusé'
    ACCEPTE = 'Accepté'
    ETAT_CHOICES = [
        (ETUDE, 'en cours d\'étude'),
        (REFUSE, 'Refusé'),
        (ACCEPTE, 'Accepté'),
    ]

    nom_bureau = models.CharField(max_length=200, null=True)
    code_tva = models.CharField(max_length=20)
    nom_et_prenom_gerant = models.CharField(max_length=200)
    diplome_gerant = models.CharField(max_length=200)
    date_de_diplome_gerant = models.DateField(default=timezone.now)
    cin_gerant = models.CharField(max_length=20)
    categorie_bureau = models.CharField(max_length=10, choices=[('liste A', 'liste A'), ('liste B', 'liste B')])
    
    date_depot_dossier = models.DateField(default=timezone.now)
    numero_agrement = models.CharField(max_length=200, blank=True)
    date_agrement = models.DateField(default=None, blank=True, null=True)
    remarque = models.TextField(null=True, blank=True)

    etat = models.CharField(
        max_length=20,
        choices=ETAT_CHOICES,
        default=ETUDE,
    )

    def clean(self):
        if self.etat == 'Accepté':
            if not self.numero_agrement:
                raise ValidationError({'numero_agrement': 'Le numéro d\'agrément est obligatoire lorsque l\'état est "Accepté".'})
            if not self.date_agrement:
                raise ValidationError({'date_agrement': 'La date d\'agrément est obligatoire lorsque l\'état est "Accepté".'})
        else:
            self.numero_agrement = ''
            self.date_agrement = None

    def save(self, *args, **kwargs):
        self.clean()
        super().save(*args, **kwargs)

    def __str__(self):
        return ""

class EntrepriseCathegorie1Et2(models.Model):
    
    ETUDE = 'en cours d\'étude'
    REFUSE = 'Refusé'
    ACCEPTE = 'Accepté'
    ETAT_CHOICES = [
        (ETUDE, 'en cours d\'étude'),
        (REFUSE, 'Refusé'),
        (ACCEPTE, 'Accepté'),
    ]

    nom_entreprise = models.CharField(max_length=200, null=True)
    code_tva = models.CharField(max_length=20)
    nom_et_prenom_gerant = models.CharField(max_length=200)
    diplome_gerant = models.CharField(max_length=200)
    date_de_diplome_gerant = models.DateField(default=timezone.now)
    cin_gerant = models.CharField(max_length=20)
    categorie_entreprise = models.CharField(max_length=10, choices=[('1', 'Catégorie 1'), ('2', 'Catégorie 2')])
    
    SPECIALITE_CHOICES = [
        ('B', 'bâtiment'),
        ('R', 'route'),
        ('VRD', 'VRD'),
    ]
    specialite_entreprise = models.CharField(max_length=200, choices=SPECIALITE_CHOICES)
    
    date_depot_dossier = models.DateField(default=timezone.now)
    numero_agrement = models.CharField(max_length=200, blank=True)
    date_agrement = models.DateField(default=None, blank=True, null=True)
    remarque = models.TextField(null=True, blank=True)

    etat = models.CharField(
        max_length=20,
        choices=ETAT_CHOICES,
        default=ETUDE,
    )

    def clean(self):
        if self.etat == 'Accepté':
            if not self.numero_agrement:
                raise ValidationError({'numero_agrement': 'Le numéro d\'agrément est obligatoire lorsque l\'état est "Accepté".'})
            if not self.date_agrement:
                raise ValidationError({'date_agrement': 'La date d\'agrément est obligatoire lorsque l\'état est "Accepté".'})
        else:
            self.numero_agrement = ''
            self.date_agrement = None

    def save(self, *args, **kwargs):
        self.clean()
        super().save(*args, **kwargs)

    def __str__(self):
        return ""

class EntrepriseCathegorie3EtPlus(models.Model):
    
    ETUDE = 'en cours d\'étude'
    REFUSE = 'Refusé'
    ACCEPTE = 'Accepté'
    ETAT_CHOICES = [
        (ETUDE, 'en cours d\'étude'),
        (REFUSE, 'Refusé'),
        (ACCEPTE, 'Accepté'),
    ]

    nom_entreprise = models.CharField(max_length=200, null=True)
    code_tva = models.CharField(max_length=20)
    nom_et_prenom_gerant = models.CharField(max_length=200)
    date_de_diplome_gerant = models.DateField(default=timezone.now)
    cin_gerant = models.CharField(max_length=20)
    categorie_entreprise = models.CharField(max_length=10, choices=[
        ('3', 'Catégorie 3'), 
        ('4', 'Catégorie 4'), 
        ('5', 'Catégorie 5'), 
        ('plus', 'Catégorie 6 et plus')
    ])
    
    SPECIALITE_CHOICES = [
        ('B', 'bâtiment'),
        ('R', 'route'),
        ('VRD', 'VRD'),
    ]
    specialite_entreprise = models.CharField(max_length=200, choices=SPECIALITE_CHOICES)
    
    date_depot_dossier = models.DateField(default=timezone.now)
    numero_agrement = models.CharField(max_length=200, blank=True)
    date_agrement = models.DateField(default=None, blank=True, null=True)
    remarque = models.TextField(null=True, blank=True)

    etat = models.CharField(
        max_length=20,
        choices=ETAT_CHOICES,
        default=ETUDE,
    )

    def clean(self):
        if self.etat == 'Accepté':
            if not self.numero_agrement:
                raise ValidationError({'numero_agrement': 'Le numéro d\'agrément est obligatoire lorsque l\'état est "Accepté".'})
            if not self.date_agrement:
                raise ValidationError({'date_agrement': 'La date d\'agrément est obligatoire lorsque l\'état est "Accepté".'})
        else:
            self.numero_agrement = ''
            self.date_agrement = None

    def save(self, *args, **kwargs):
        self.clean()
        super().save(*args, **kwargs)

    def __str__(self):
        return ""


class Personel(models.Model):
    code_tva = models.ForeignKey(TVACode, on_delete=models.CASCADE, verbose_name="Code TVA")
    nom = models.CharField(max_length=200)
    prenom = models.CharField(max_length=200)
    cin = models.CharField(max_length=20)
    specialite = models.CharField(max_length=200)
    nom_employeur = models.CharField(max_length=200)
    date_embauche = models.DateField()

    def __str__(self):
        return f"{self.nom} {self.prenom}"


class Materiel(models.Model):
    code_tva = models.ForeignKey(TVACode, on_delete=models.CASCADE, verbose_name="Code TVA")
    nom = models.CharField(max_length=200)
    numero_serie = models.CharField(max_length=50)
    type = models.CharField(max_length=200)
    nom_employeur = models.CharField(max_length=200)
    date_acquisition = models.DateField()

    def __str__(self):
        return self.nom
