from django.contrib import admin
from .models import BureauDEtude, Personel, Materiel, IngenieurConseil, EntrepriseCathegorie1Et2, EntrepriseCathegorie3EtPlus, BureauGeometreExpert, BureauDeControle, TVACode


class TVACodeAdmin(admin.ModelAdmin):
    list_display = ('code', 'nom_entreprise_ou_bureau', 'date_patente', 'category')
    search_fields = ('code', 'nom_entreprise_ou_bureau')
    list_filter = ('category',)


class BureauDEtudeAdmin(admin.ModelAdmin):
    list_display = ('nom_bureau', 'code_tva', 'nom_et_prenom_gerant', 'date_de_diplome_gerant', 'date_depot_dossier', 'numero_agrement', 'date_agrement')
    search_fields = ('nom_bureau', 'nom_et_prenom_gerant', 'code_tva__code')  
    list_filter = ('date_depot_dossier',)

class BureauDeControleAdmin(admin.ModelAdmin):
    list_display = ('nom_bureau', 'code_tva', 'nom_et_prenom_gerant', 'date_de_diplome_gerant', 'date_depot_dossier', 'numero_agrement', 'date_agrement')
    search_fields = ('nom_bureau', 'nom_et_prenom_gerant', 'code_tva__code')
    list_filter = ('date_depot_dossier',)

class BureauGeometreExpertAdmin(admin.ModelAdmin):
    list_display = ('nom_bureau', 'code_tva', 'nom_et_prenom_gerant', 'date_de_diplome_gerant', 'date_depot_dossier', 'numero_agrement', 'date_agrement')
    search_fields = ('nom_bureau', 'nom_et_prenom_gerant', 'code_tva__code')
    list_filter = ('date_depot_dossier',)

class EntrepriseCathegorie1Et2Admin(admin.ModelAdmin):
    list_display = ('nom_entreprise', 'code_tva', 'nom_et_prenom_gerant',  'date_depot_dossier', 'numero_agrement', 'date_agrement')
    search_fields = ('nom_entreprise', 'nom_et_prenom_gerant', 'code_tva__code')
    list_filter = ('date_depot_dossier',)

class EntrepriseCathegorie3EtPlusAdmin(admin.ModelAdmin):
    list_display = ('nom_entreprise', 'code_tva', 'nom_et_prenom_gerant',  'date_depot_dossier', 'numero_agrement', 'date_agrement')
    search_fields = ('nom_entreprise', 'nom_et_prenom_gerant', 'code_tva__code')
    list_filter = ('date_depot_dossier',)

class IngenieurConseilAdmin(admin.ModelAdmin):
    list_display = ( 'code_tva', 'nom_et_prenom', 'cin', 'date_de_diplome', 'date_depot_dossier', 'numero_agrement', 'date_agrement')
    search_fields = ( 'nom_et_prenom',  'cin', 'code_tva__code')
    list_filter = ('date_depot_dossier',)

class PersonelAdmin(admin.ModelAdmin):
    autocomplete_fields = ['code_tva']  
    list_display = ('nom', 'prenom', 'cin', 'specialite', 'nom_employeur', 'code_tva', 'date_embauche')
    search_fields = ('nom', 'prenom', 'code_tva__code')
    list_filter = ('date_embauche',)

class MaterielAdmin(admin.ModelAdmin):
    autocomplete_fields = ['code_tva']  
    list_display = ('nom', 'numero_serie', 'type', 'nom_employeur', 'code_tva', 'date_acquisition')
    search_fields = ('nom', 'type', 'code_tva__code')
    list_filter = ('date_acquisition',)

admin.site.register(TVACode, TVACodeAdmin)
admin.site.register(BureauDEtude, BureauDEtudeAdmin)
admin.site.register(Personel, PersonelAdmin)
admin.site.register(Materiel, MaterielAdmin)
admin.site.register(IngenieurConseil, IngenieurConseilAdmin)
admin.site.register(EntrepriseCathegorie1Et2, EntrepriseCathegorie1Et2Admin)
admin.site.register(EntrepriseCathegorie3EtPlus, EntrepriseCathegorie3EtPlusAdmin)
admin.site.register(BureauGeometreExpert, BureauGeometreExpertAdmin)
admin.site.register(BureauDeControle, BureauDeControleAdmin)
