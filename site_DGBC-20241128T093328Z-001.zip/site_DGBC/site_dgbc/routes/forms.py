from django import forms
from django.contrib.auth.forms import AuthenticationForm
from django.utils.translation import gettext_lazy as _


class CustomAuthenticationForm(AuthenticationForm):
    username = forms.CharField(
        label=_("Nom d'utilisateur"),
        max_length=254,
        widget=forms.TextInput(attrs={'autofocus': True, 'placeholder': 'Nom d\'utilisateur'}),
    )
    password = forms.CharField(
        label=_("Mot de passe"),
        strip=False,
        widget=forms.PasswordInput(attrs={'placeholder': 'Mot de passe'}),
    )
