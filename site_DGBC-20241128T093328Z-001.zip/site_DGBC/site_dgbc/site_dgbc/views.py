from django.shortcuts import render, get_object_or_404
from django.views.generic import ListView
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator

from service_etude.models import Projetenphaseetude, Projetprevu
from service_travaux.models import ChantierEncour, PersonnelChantier, MaterielChantier
from service_daf.models import VoitureService, EtatVoiture

@login_required
def tableau_bord_drg(request):
   return render(request, 'page_principal/tableau_bord_drg.html')


def index(request):
    return render(request, 'page_principal/index.html')

def login(request):
    return render(request, 'page_principal/login.html')

@login_required
def liste_projets_en_phase_etude(request):
    projets = Projetenphaseetude.objects.all()
    return render(request, 'service_etude/liste_projets_en_phase_etude.html', {'projets': projets})

@login_required
def liste_projets_prevus(request):
    projets = Projetprevu.objects.all()
    return render(request, 'service_etude/liste_projets_prevus.html', {'projets': projets})

@login_required
def chantiers_en_cours(request):
    chantiers = ChantierEncour.objects.all()
    return render(request, 'service_travaux/chantiers_en_cours.html', {'chantiers': chantiers})

@login_required
def detail_chantier(request, chantier_id):
    chantier = get_object_or_404(ChantierEncour, pk=chantier_id)
    return render(request, 'service_travaux/detail_chantier.html', {'chantier': chantier})

@login_required
def liste_personnel(request, chantier_id):
    chantier = get_object_or_404(ChantierEncour, pk=chantier_id)
    personnel = PersonnelChantier.objects.filter(chantier_encour=chantier)
    return render(request, 'service_travaux/liste_personnel.html', {'personnel': personnel})

@login_required
def liste_materiel(request, chantier_id):
    chantier = get_object_or_404(ChantierEncour, pk=chantier_id)
    materiel = MaterielChantier.objects.filter(chantier_encour=chantier)
    return render(request, 'service_travaux/liste_materiel.html', {'materiel': materiel})

@login_required
def liste_voiture_services(request):
    voitures = VoitureService.objects.all()
    return render(request, 'service_daf/liste_voiture_services.html', {'voitures': voitures})

def etat_voiture(request):
    # Récupérer tous les objets EtatVoiture
    etat_voitures = EtatVoiture.objects.all()
    # Rendre le template 'etat_voiture_dgbc.html' en passant les voitures dans le contexte
    return render(request, 'service_daf/etat_voiture_dgbc.html', {'etat_voitures': etat_voitures})
