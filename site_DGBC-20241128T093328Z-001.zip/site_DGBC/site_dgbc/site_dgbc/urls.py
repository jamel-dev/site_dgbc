from django.contrib import admin
from django.urls import path, include
from .views import (
    liste_projets_en_phase_etude, liste_voiture_services, chantiers_en_cours, 
    liste_projets_prevus, tableau_bord_drg, index, login
)
from django.contrib.auth import views as auth_views

# Définition des URL pour l'application principale

urlpatterns = [
    # URL pour le tableau de bord DRG
    path('tableau_bord_drg/', tableau_bord_drg, name='tableau_bord_drg'),

    # URL pour la page d'accueil
    path('index.html', index, name='index'),

    # URL pour la page de connexion
    path('login/', auth_views.LoginView.as_view(template_name='page_principal/login.html'), name='login'),

    # URL pour l'administration Django
    path('admin/', admin.site.urls),

    # Inclure les URLs de l'application "service_agrement"
    path('service_agrement/', include('service_agrement.urls')),

    # Inclure les URLs de l'application "service_etude"
    path('service_etude/', include('service_etude.urls')),

    # Inclure les URLs de l'application "service_travaux"
    path('service_travaux/', include('service_travaux.urls')),

    # Inclure les URLs de l'application "service_daf"
    path('service_daf/', include('service_daf.urls')),

    # Inclure les URLs de l'application "service_intelligence_artificielle"
    path('service_intelligence_artificielle/', include('service_intelligence_artificielle.urls')),

    # URLs pour les fonctions JavaScript

    # URL pour la liste des projets prévus
    path('projets_prevus/', liste_projets_prevus, name='projets_prevus'),

    # URL pour la liste des projets en phase d'étude
    path('projets_en_phase_etude/', liste_projets_en_phase_etude, name='projets_en_phase_etude'),

    # URL pour la liste des voitures
    path('liste_voitures/', liste_voiture_services, name='liste_voitures'),

    # URL pour la liste des chantiers en cours
    path('chantiers-en-cours/', chantiers_en_cours, name='chantiers_en_cours'),
]
