from django.shortcuts import render, get_object_or_404
from .models import ChantierEncour, PersonnelChantier, MaterielChantier

def index(request):
    return render(request, 'service_travaux/index.html')
    
def chantiers_en_cours(request):
    chantiers = ChantierEncour.objects.all()
    return render(request, 'service_travaux/chantiers_en_cours.html', {'chantiers': chantiers})

def detail_chantier(request, chantier_id):
    chantier = get_object_or_404(ChantierEncour, pk=chantier_id)
    return render(request, 'service_travaux/detail_chantier.html', {'chantier': chantier})

def liste_personnel(request, chantier_id):
    chantier = get_object_or_404(ChantierEncour, pk=chantier_id)
    personnel = PersonnelChantier.objects.filter(chantier_encour=chantier)
    return render(request, 'service_travaux/liste_personnel.html', {'personnel': personnel, 'chantier': chantier})

def liste_materiel(request, chantier_id):
    chantier = get_object_or_404(ChantierEncour, pk=chantier_id)
    materiel = MaterielChantier.objects.filter(chantier_encour=chantier)
    return render(request, 'service_travaux/liste_materiel.html', {'materiel': materiel, 'chantier': chantier})
