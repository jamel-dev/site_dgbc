from django.contrib import admin
from .models import ChantierEncour, MaterielChantier, PersonnelChantier

class ChantierEncourAdmin(admin.ModelAdmin):
    list_display = [field.name for field in ChantierEncour._meta.fields]

class MaterielChantierAdmin(admin.ModelAdmin):
    list_display = [field.name for field in MaterielChantier._meta.fields]

class PersonnelChantierAdmin(admin.ModelAdmin):
    list_display = [field.name for field in PersonnelChantier._meta.fields]

admin.site.register(ChantierEncour, ChantierEncourAdmin)
admin.site.register(MaterielChantier, MaterielChantierAdmin)
admin.site.register(PersonnelChantier, PersonnelChantierAdmin)
