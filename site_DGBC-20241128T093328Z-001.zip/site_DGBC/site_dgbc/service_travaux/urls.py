from django.urls import path
from .views import chantiers_en_cours, detail_chantier, liste_personnel, liste_materiel

urlpatterns = [
    path('chantiers/', chantiers_en_cours, name='chantiers_en_cours'),
    path('chantier/<int:chantier_id>/', detail_chantier, name='detail_chantier'),
    path('chantier/<int:chantier_id>/personnel/', liste_personnel, name='liste_personnel'),
    path('chantier/<int:chantier_id>/materiel/', liste_materiel, name='liste_materiel'),
]
