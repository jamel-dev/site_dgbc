from django.core.management.base import BaseCommand
from service_travaux.models import ChantierEncour, FicheChantier

class Command(BaseCommand):
    help = 'Met à jour les valeurs de nom_projet dans ChantierEncour pour correspondre aux clés primaires de FicheChantier'

    def handle(self, *args, **kwargs):
        for chantier in ChantierEncour.objects.all():
            try:
                fiche_chantier = FicheChantier.objects.get(nom_projet=chantier.nom_projet)
                chantier.nom_projet = fiche_chantier
                chantier.save()
                self.stdout.write(self.style.SUCCESS(f'Successfully updated {chantier.nom_projet}'))
            except FicheChantier.DoesNotExist:
                self.stdout.write(self.style.ERROR(f'FicheChantier with nom_projet={chantier.nom_projet} does not exist'))
