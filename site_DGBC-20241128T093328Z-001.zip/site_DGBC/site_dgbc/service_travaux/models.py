from django.db import models
from django.utils.translation import gettext_lazy as _

class ChantierEncour(models.Model):
    PHASE_CHOICES = [
        ('phase_fondation', 'Phase Fondation'),
        ('phase_elevation', 'Phase Élévation'),
        ('phase_finition', 'Phase Finition'),
        ('phase_reception_provisoire', 'Phase Réception Provisoire'),
        ('phase_reception_definitive', 'Phase Réception Définitive'),
        ('phase_reglement_definitif', 'Phase Règlement Définitif'),
    ]

    nom_projet = models.CharField(max_length=200, verbose_name="Nom du Projet")
    responsable = models.CharField(max_length=200, verbose_name="Responsable du Projet")
    cin_responsable = models.CharField(max_length=20, verbose_name="CIN du Responsable")
    grade_responsable = models.CharField(max_length=50, verbose_name="Grade du Responsable", null=True, blank=True)
    budget = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Budget du Projet")
    maitre_d_oeuvre = models.CharField(max_length=200, verbose_name="Maître d'Oeuvre")
    entrepreneur_genie_civil = models.TextField(null=True, blank=True, verbose_name="Entrepreneur Lot Génie Civil")
    entrepreneur_fluide = models.TextField(null=True, blank=True, verbose_name="Entrepreneur Lot Fluide")
    entrepreneur_electricite = models.TextField(null=True, blank=True, verbose_name="Entrepreneur Lot Électricité")
    entrepreneur_securite_incendie = models.TextField(null=True, blank=True, verbose_name="Entrepreneur Lot Sécurité Incendie")
    concepteur_genie_civil = models.TextField(null=True, blank=True, verbose_name="Concepteur Lot Génie Civil")
    concepteur_fluide = models.TextField(null=True, blank=True, verbose_name="Concepteur Lot Fluide")
    concepteur_electricite = models.TextField(null=True, blank=True, verbose_name="Concepteur Lot Électricité")
    concepteur_securite_incendie = models.TextField(null=True, blank=True, verbose_name="Concepteur Lot Sécurité Incendie")
    architecte = models.TextField(null=True, blank=True, verbose_name="Architecte(s)")
    etat_projet = models.CharField(max_length=50, choices=PHASE_CHOICES, verbose_name="État du Projet")
    controleur_technique = models.CharField(max_length=100, null=True, blank=True, verbose_name="Contrôleur Technique")
    date_debut = models.DateField(verbose_name="Date de Début")
    date_fin = models.DateField(verbose_name="Date de Fin")
    remarque = models.TextField(blank=True, default='', verbose_name="Remarques")

    def __str__(self):
        return self.nom_projet

class PersonnelChantier(models.Model):
    chantier_encour = models.ForeignKey(ChantierEncour, on_delete=models.CASCADE, verbose_name=_("Chantier en cours"))
    nom = models.CharField(max_length=100, verbose_name="Nom")
    prenom = models.CharField(max_length=100, verbose_name="Prénom")
    cin = models.CharField(max_length=20, unique=True, verbose_name="CIN")
    diplome = models.CharField(max_length=100, verbose_name="Diplôme")
    specialite = models.CharField(max_length=100, verbose_name="Spécialité")
    date_embauche = models.DateField(verbose_name="Date d'embauche")

    class Meta:
        unique_together = ('chantier_encour', 'cin')
        verbose_name = "Personnel Chantier"
        verbose_name_plural = "Personnels Chantier"

    def __str__(self):
        return f"Projet: {self.chantier_encour.nom_projet}, Nom: {self.nom}, Prénom: {self.prenom}, CIN: {self.cin}, Spécialité: {self.specialite}, Diplôme: {self.diplome}, Date d'embauche: {self.date_embauche}"

class MaterielChantier(models.Model):
    chantier_encour = models.ForeignKey(ChantierEncour, on_delete=models.CASCADE, verbose_name=_("Chantier en cours"))
    nom_materiel = models.CharField(max_length=200, verbose_name="Nom du Matériel")
    TYPE_CHOICES = [
        ('roulent', 'Roulent'),
        ('materiel', 'Matériel'),
    ]
    type_materiel = models.CharField(max_length=10, choices=TYPE_CHOICES, verbose_name="Type de Matériel")
    numero_serie = models.CharField(max_length=17, blank=True, null=True, verbose_name="Numéro de Série", help_text="Format: XXXX-Tunis-XXXX")
    date_acquisition = models.DateField(verbose_name="Date d'Acquisition")

    class Meta:
        unique_together = ('chantier_encour', 'numero_serie')
        verbose_name = "Matériel Chantier"
        verbose_name_plural = "Matériels Chantier"

    def __str__(self):
        return f"Nom du Matériel: {self.nom_materiel}, Numéro de Série: {self.numero_serie}, Type de Matériel: {self.type_materiel}, Date d'Acquisition: {self.date_acquisition}"
