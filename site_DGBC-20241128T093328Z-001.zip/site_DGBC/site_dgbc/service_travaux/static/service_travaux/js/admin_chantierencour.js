document.addEventListener('DOMContentLoaded', function() {
    const ficheChantierSelect = document.querySelector('#id_fiche_chantier');

    if (ficheChantierSelect) {
        ficheChantierSelect.addEventListener('change', function() {
            const ficheChantierId = this.value;

            if (ficheChantierId) {
                fetch(`/ajax/get-fiche-chantier-details/?fiche_chantier_id=${ficheChantierId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.error) {
                            console.error(data.error);
                        } else {
                            document.querySelector('#id_nom_projet').value = data.nom_projet;
                            document.querySelector('#id_responsable').value = data.responsable;
                            document.querySelector('#id_cin_responsable').value = data.cin_responsable;
                            document.querySelector('#id_budget').value = data.budget;
                            document.querySelector('#id_maitre_d_oeuvre').value = data.maitre_d_oeuvre;
                            document.querySelector('#id_entrepreneur').value = data.entrepreneur;
                            document.querySelector('#id_concepteur').value = data.concepteur;
                            document.querySelector('#id_architecte').value = data.architecte;
                            document.querySelector('#id_controleur_technique').value = data.controleur_technique;
                            document.querySelector('#id_date_debut').value = data.date_debut;
                            document.querySelector('#id_date_fin').value = data.date_fin;
                            document.querySelector('#id_remarque').value = data.remarque;
                        }
                    })
                    .catch(error => console.error('Error fetching data:', error));
            }
        });
    }
});
