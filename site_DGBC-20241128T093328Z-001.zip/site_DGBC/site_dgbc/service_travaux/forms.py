from django import forms
from .models import ChantierEncour, FicheChantier

class ChantierEncourForm(forms.ModelForm):
    fiche_chantier = forms.ModelChoiceField(
        queryset=FicheChantier.objects.all(), 
        label="Fiche Chantier",
        required=True
    )

    class Meta:
        model = ChantierEncour
        fields = ['fiche_chantier', 'nom_projet', 'responsable', 'cin_responsable', 'grade_responsable', 'budget', 'maitre_d_oeuvre', 'entrepreneur', 'concepteur', 'architecte', 'controleur_technique', 'date_debut', 'date_fin', 'remarque']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in ['nom_projet', 'responsable', 'cin_responsable', 'budget', 'maitre_d_oeuvre', 'entrepreneur', 'concepteur', 'architecte', 'controleur_technique', 'date_debut', 'date_fin']:
            self.fields[field].widget.attrs['readonly'] = True
