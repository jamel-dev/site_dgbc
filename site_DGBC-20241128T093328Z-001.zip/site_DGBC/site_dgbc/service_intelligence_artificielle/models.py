from django.db import models

class UserQuestion(models.Model):
    user_question = models.CharField(max_length=255)
    asked_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.user_question

class Question(models.Model):
    question_text = models.CharField(max_length=255)
    response = models.OneToOneField('Response', on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return self.question_text

class Response(models.Model):
    response_text = models.TextField()

    def __str__(self):
        return self.response_text[:50]
