from django.shortcuts import render
from .models import UserQuestion, Question
from difflib import get_close_matches
import difflib

def index(request):
    return render(request, 'service_intelligence_artificielle/index.html')

def chatbot(request):
    if 'messages' not in request.session:
        request.session['messages'] = []

    messages = request.session['messages']

    if request.method == "POST":
        user_question = request.POST.get('user_question')
        if user_question:
            # Enregistrement de la question de l'utilisateur dans la base de données
            UserQuestion.objects.create(user_question=user_question)
            messages.append({'sender': 'user', 'text': user_question})

            # Recherche de la question dans la base de données
            try:
                question = Question.objects.get(question_text__iexact=user_question)
                response_text = question.response.response_text
            except Question.DoesNotExist:
                # Si la question exacte n'est pas trouvée, chercher une correspondance approximative
                similar_questions = get_close_matches(user_question, Question.objects.values_list('question_text', flat=True))
                if similar_questions:
                    # Récupérer la réponse de la première question similaire
                    similar_question = Question.objects.get(question_text__iexact=similar_questions[0])
                    response_text = similar_question.response.response_text
                else:
                    response_text = "Désolé, je n'ai pas de réponse à cette question."

            messages.append({'sender': 'bot', 'text': response_text})

    request.session['messages'] = messages

    return render(request, 'service_intelligence_artificielle/chatbot.html', {'messages': messages})
