document.addEventListener('DOMContentLoaded', function() {
    const nomProjetSelect = document.querySelector('#id_nom_projet');
    const responsableInput = document.querySelector('#id_responsable');
    const cinResponsableInput = document.querySelector('#id_cin_responsable');
    const budgetInput = document.querySelector('#id_budget');
    // Ajoutez d'autres sélecteurs pour les autres champs du formulaire

    if (nomProjetSelect) {
        nomProjetSelect.addEventListener('change', function() {
            const nomProjet = this.value;

            if (nomProjet) {
                fetch(`/ajax/get-fiche-chantier-details/?nom_projet=${nomProjet}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.error) {
                            console.error(data.error);
                        } else {
                            responsableInput.value = data.responsable;
                            cinResponsableInput.value = data.cin_responsable;
                            budgetInput.value = data.budget;
                            // Remplissez les autres champs de la même manière
                        }
                    })
                    .catch(error => console.error('Error fetching data:', error));
            }
        });
    }
});
