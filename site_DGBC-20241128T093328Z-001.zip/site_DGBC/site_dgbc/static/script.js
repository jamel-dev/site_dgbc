document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('chatbot-form');
    const input = document.getElementById('chatbot-input');
    const output = document.getElementById('chatbot-output');
    const response = document.getElementById('chatbot-response');

    form.addEventListener('submit', function(event) {
        event.preventDefault();
        const question = input.value.trim();

        if (question) {
            output.innerHTML = 'Vous : ' + question;
            input.value = '';

            // Envoyer la requête AJAX
            const xhr = new XMLHttpRequest();
            xhr.open('GET', '/obtenir_reponse/?question=' + encodeURIComponent(question), true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                    const responseText = JSON.parse(xhr.responseText);
                    response.innerHTML = 'Chatbot : ' + responseText.reponse;
                }
            };
            xhr.send();
        }
    });
});
