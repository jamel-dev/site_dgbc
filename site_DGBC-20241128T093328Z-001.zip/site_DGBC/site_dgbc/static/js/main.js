document.addEventListener("DOMContentLoaded", function() {
    var concepteursTable = document.getElementById("concepteurs-table");
    var entreprisesTable = document.getElementById("entreprises-table");
    var geometresTable = document.getElementById("geometres-table");

    var concepteursLink = document.querySelector("a[href='#concepteurs']");
    var entreprisesLink = document.querySelector("a[href='#entreprises']");
    var geometresLink = document.querySelector("a[href='#geometres']");
    var menuLink = document.querySelector(".navbar-brand"); // Lien du bouton "Menu"

    // Fonction pour masquer toutes les tables et les titres
    function hideAllTablesAndTitles() {
        concepteursTable.classList.add("d-none");
        entreprisesTable.classList.add("d-none");
        geometresTable.classList.add("d-none");
        document.getElementById("concepteurs").classList.add("d-none");
        document.getElementById("entreprises").classList.add("d-none");
        document.getElementById("geometres").classList.add("d-none");
    }

    // Appel de la fonction pour masquer toutes les tables et les titres
    hideAllTablesAndTitles();

    concepteursLink.addEventListener("click", function(event) {
        event.preventDefault();
        hideAllTablesAndTitles();
        concepteursTable.classList.remove("d-none");
        document.getElementById("concepteurs").classList.remove("d-none");
    });

    entreprisesLink.addEventListener("click", function(event) {
        event.preventDefault();
        hideAllTablesAndTitles();
        entreprisesTable.classList.remove("d-none");
        document.getElementById("entreprises").classList.remove("d-none");
    });

    geometresLink.addEventListener("click", function(event) {
        event.preventDefault();
        hideAllTablesAndTitles();
        geometresTable.classList.remove("d-none");
        document.getElementById("geometres").classList.remove("d-none");
    });

    // Ajout d'un gestionnaire d'événements pour le lien du bouton "Menu"
    menuLink.addEventListener("click", function(event) {
        // Masquer toutes les tables et les titres lorsque vous cliquez sur le bouton "Menu"
        hideAllTablesAndTitles();
    });
});