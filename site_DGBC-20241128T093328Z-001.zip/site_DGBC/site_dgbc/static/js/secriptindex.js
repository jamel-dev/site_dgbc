jQuery(window).on('load',  function() {
				new JCaption('img.caption');
			});
var sp_preloader = '0';

var sp_gotop = '1';

var sp_offanimation = 'default';


jQuery(document).ready(function($){
	jQuery('#camera_wrap_156').camera({
		alignment			: 'center',
		autoAdvance			: true,
		easing				: 'easeInOutExpo',
		fx					: 'random',
		gridDifference		: 250,	//to make the grid blocks slower than the slices, this value must be smaller than transPeriod
		height				: '40%px',
		imagePath			: 'http://www.commune-zarzisnord.gov.tn/modules/mod_je_camera/images/',
		hover				: true,
		loader				: 'none',
		loaderColor			: '#EEEEEE', 
		loaderBgColor		: '#222222',
		loaderOpacity		: .8,	//0, .1, .2, .3, .4, .5, .6, .7, .8, .9, 1
		loaderPadding		: 2,	//how many empty pixels you want to display between the loader and its background
		loaderStroke		: 7,	//the thickness both of the pie loader and of the bar loader. Remember: for the pie, the loader thickness must be less than a half of the pie diameter	
		pieDiameter			: 38,
		piePosition			: 'rightTop',		
		barDirection		: 'leftToRight',
		barPosition			: 'bottom',
		navigation			: true,
		playPause			: false,
		pauseOnClick		: true,
		navigationHover		: true,
		pagination			: true,
		overlayer			: true,	//a layer on the images to prevent the users grab them simply by clicking the right button of their mouse (.camera_overlayer)
		opacityOnGrid		: false,	//true, false. Decide to apply a fade effect to blocks and slices: if your slideshow is fullscreen or simply big, I recommend to set it false to have a smoother effect
		minHeight			: '200px',	//you can also leave it blank
		portrait			: false, //true, false. Select true if you don't want that your images are cropped
		cols				: 6,
		rows				: 4,
		slicedCols			: 12,
		slicedRows			: 8,
		slideOn				: 'random',
		thumbnails			: true,
		time				: 7000,
		transPeriod			: 1500,
		//Mobile
		mobileAutoAdvance	: true, //true, false. Auto-advancing for mobile devices
		mobileEasing		: '',	//leave empty if you want to display the same easing on mobile devices and on desktop etc.
		mobileFx			: '',	//leave empty if you want to display the same effect on mobile devices and on desktop etc.
		mobileNavHover		: true	//same as above, but only for mobile devices
		
	});
});
