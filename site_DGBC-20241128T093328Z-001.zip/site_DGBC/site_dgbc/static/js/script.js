function toggleForms() {
    var selectedOption = document.getElementById('choix_du_concepteur').value;
    var sslForm = document.getElementById('ssl-form');
    var pageLoadForm = document.getElementById('page-load-form');
    var altAttributeForm = document.getElementById('alt-attribute-form');
  
    // Cacher tous les formulaires
    if (sslForm) sslForm.style.display = 'none';
    if (pageLoadForm) pageLoadForm.style.display = 'none';
    if (altAttributeForm) altAttributeForm.style.display = 'none';


    // Afficher le formulaire correspondant à l'option sélectionnée
    if (selectedOption === 'ingenieur_conseil') {
        if (sslForm) sslForm.style.display = 'block';
    } else if (selectedOption === 'bureau_d_etude') {
        if (pageLoadForm) pageLoadForm.style.display = 'block';
    } else if (selectedOption === 'bureau_de_control') {
        if (altAttributeForm) altAttributeForm.style.display = 'block';
    } 
}

function updateFormValues(formId) {
    var form = document.getElementById(formId);
    if (!form) return; // Vérifier si le formulaire existe
    var checkboxes = form.querySelectorAll('input[type="checkbox"]:checked');
    var values = Array.from(checkboxes).map(function(checkbox) {
        return checkbox.value;
    }).join(', ');
    form.querySelector('input[type="hidden"]').value = values;
}

// Appel initial pour gérer l'affichage des formulaires
toggleForms();

// Écouteur d'événement pour détecter les changements dans la sélection de concepteur
document.getElementById('choix_du_concepteur').addEventListener('change', toggleForms);

// Attend que le DOM soit entièrement chargé
document.addEventListener("DOMContentLoaded", function() {
    // Sélectionne l'élément de sélection du concepteur
    var selectElement = document.getElementById('choix_du_concepteur');
    // Sélectionne les formulaires pour chaque type de concepteur
    var ingenieurconseilForm = document.getElementById('ingenieur_conseil_form');
    var bureauDetudeForm = document.getElementById('bureau_d_etude_form');
    var bureauDControlForm = document.getElementById('bureau_de_control_form');

    // Ajoute un écouteur d'événements pour le changement de sélection
    selectElement.addEventListener('change', function() {
        var selectValue = this.value;

        // Cache tous les formulaires
        ingenieurconseilForm.style.display = 'none';
        bureauDetudeForm.style.display = 'none';
        bureauDControlForm.style.display = 'none';

        // Affiche le formulaire correspondant à l'option sélectionnée
        if (selectValue === 'ingenieur_conseil') {
            ingenieurconseilForm.style.display = 'block';
        } else if (selectValue === 'bureau_d_etude') {
            bureauDetudeForm.style.display = 'block';
        } else if (selectValue === 'bureau_de_control') {
            bureauDControlForm.style.display = 'block';
        }
    });

    // Stocke la valeur par défaut de la sélection
    var defaultValue = selectElement.value;
    // Affiche le formulaire correspondant à la valeur par défaut
    if (defaultValue === 'ingenieur_conseil') {
        ingenieurconseilForm.style.display = 'block';
    } else if (defaultValue === 'bureau_d_etude') {
        bureauDetudeForm.style.display = 'block';
    } else if (defaultValue === 'bureau_de_control') {
        bureauDControlForm.style.display = 'block';
    }
});

