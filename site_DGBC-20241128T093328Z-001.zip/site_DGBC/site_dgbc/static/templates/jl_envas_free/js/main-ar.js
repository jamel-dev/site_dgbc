/**
* @package Helix3 Framework
* @author JoomShaper http://www.joomshaper.com
* @copyright Copyright (c) 2010 - 2016 JoomShaper
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
*/

jQuery(function ($) {


		function manageHeader() {
			if ($(this).scrollTop() > 35) { 
				$(".mod-languages").stop().animate({right: "30px", top: "0px"});
				$(".mod-languages li").addClass("vertical");
				//$("#sp-top3").stop().animate({paddingTop: "0px"}, 1);
			} else {
				$(".mod-languages").stop().animate({right: "30px", top: "0px"});
				$(".mod-languages li").removeClass("vertical");
				//$("#sp-top3").stop().animate({paddingTop: "15px"}, 1);
			}
		}
		
	manageHeader();
	
	$(window).scroll(
		function(){
			manageHeader();
		}
	);		

});
